/**
 *  iShiWuPai入口文件
 */

import React from 'react';
import { AppRegistry } from 'react-native';
import Root from './app/root';

AppRegistry.registerComponent('iShiWuPai', () => Root);